'use client';
import { useTheme } from 'next-themes';
import { Sun, Moon } from 'lucide-react';
import { useEffect, useState } from 'react';
import styles from '../app/styles/navbar.module.scss';

export default function ThemeToggle() {
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) {
    // Evita desajustes entre SSR y cliente
    return null;
  }

  const isDark = theme === 'dark';

  return (
    <button
      className={`${styles.toggle} ${isDark ? styles['toggle--dark'] : ''}`}
      onClick={() => setTheme(isDark ? 'light' : 'dark')}
      aria-label="Toggle theme"
    >
      <div className={styles.toggle__circle}>
        {isDark ? <Sun size={18} /> : <Moon size={18} />}
      </div>
      <span className={styles.toggle__text}>
        {isDark ? 'LIGHT MODE' : 'DARK MODE'}
      </span>
    </button>
  );
}